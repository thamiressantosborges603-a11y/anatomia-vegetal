# Anatomia Ambiental — Java

Projeto escolar completo usando Java 17, Spring Boot, Thymeleaf, JPA e banco H2.

## Requisitos
- JDK 17 ou superior
- VS Code (Extension Pack for Java) ou IntelliJ IDEA
- Não precisa de XAMPP.

## Executar
Abra esta pasta no VS Code/IntelliJ como projeto Maven e execute:
`br.com.anatomiaambiental.AnatomiaAmbientalApplication`

Ou, se o Maven estiver instalado:
`mvn spring-boot:run`

Depois abra http://localhost:8080

## Login de demonstração
E-mail: aluno@escola.com
Senha: 123456

## Páginas
/ /raizes /caules /folhas /aluno /quiz /resultado

O banco H2 é criado automaticamente em ./data.
