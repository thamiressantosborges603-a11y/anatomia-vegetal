package br.com.anatomiaambiental.config;
import br.com.anatomiaambiental.model.Aluno; import br.com.anatomiaambiental.repository.AlunoRepository; import br.com.anatomiaambiental.util.SenhaUtil;
import org.springframework.boot.CommandLineRunner; import org.springframework.context.annotation.*;
@Configuration public class DataInitializer {
 @Bean CommandLineRunner demo(AlunoRepository r){return a->{if(r.findByEmail("aluno@escola.com").isEmpty())r.save(new Aluno("Aluno Demonstração","aluno@escola.com",SenhaUtil.hash("123456")));};}
}
