package br.com.anatomiaambiental.repository;
import br.com.anatomiaambiental.model.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface ResultadoRepository extends JpaRepository<Resultado,Long>{ List<Resultado> findTop5ByAlunoOrderByDataHoraDesc(Aluno aluno); }
