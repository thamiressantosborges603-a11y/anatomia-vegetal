package br.com.anatomiaambiental.model;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity @Table(name="resultados")
public class Resultado {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) private Aluno aluno;
 @Column(nullable=false) private int acertos;
 @Column(nullable=false) private int total;
 @Column(nullable=false) private LocalDateTime dataHora;
 public Resultado(){}
 public Resultado(Aluno aluno,int acertos,int total){this.aluno=aluno;this.acertos=acertos;this.total=total;this.dataHora=LocalDateTime.now();}
 public Long getId(){return id;} public Aluno getAluno(){return aluno;} public int getAcertos(){return acertos;} public int getTotal(){return total;} public LocalDateTime getDataHora(){return dataHora;}
}
