package br.com.anatomiaambiental.util;
import java.nio.charset.StandardCharsets; import java.security.MessageDigest;
public final class SenhaUtil {
 private SenhaUtil(){}
 public static String hash(String s){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));StringBuilder x=new StringBuilder();for(byte v:b)x.append(String.format("%02x",v));return x.toString();}catch(Exception e){throw new IllegalStateException(e);}}
 public static boolean confere(String s,String h){return hash(s).equals(h);}
}
