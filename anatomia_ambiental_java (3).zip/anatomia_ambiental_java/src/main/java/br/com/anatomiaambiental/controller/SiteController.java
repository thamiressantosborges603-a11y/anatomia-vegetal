package br.com.anatomiaambiental.controller;
import br.com.anatomiaambiental.model.*; import br.com.anatomiaambiental.repository.*; import br.com.anatomiaambiental.util.SenhaUtil;
import jakarta.servlet.http.HttpSession; import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.web.bind.annotation.*; import java.util.*;
@Controller public class SiteController {
 private final AlunoRepository alunos; private final ResultadoRepository resultados;
 public SiteController(AlunoRepository a,ResultadoRepository r){alunos=a;resultados=r;}
 @GetMapping("/") String inicio(){return "index";} @GetMapping("/raizes") String raizes(){return "raizes";} @GetMapping("/caules") String caules(){return "caules";} @GetMapping("/folhas") String folhas(){return "folhas";}
 @GetMapping("/aluno") String aluno(HttpSession s){return s.getAttribute("aluno")!=null?"redirect:/quiz":"aluno";}
 @PostMapping("/login") String login(@RequestParam String email,@RequestParam String senha,HttpSession s,Model m){
  Optional<Aluno> a=alunos.findByEmail(email.trim().toLowerCase());
  if(a.isPresent()&&SenhaUtil.confere(senha,a.get().getSenha())){s.setAttribute("aluno",a.get());return "redirect:/quiz";}
  m.addAttribute("erro","E-mail ou senha incorretos.");return "aluno";
 }
 @GetMapping("/logout") String logout(HttpSession s){s.invalidate();return "redirect:/";}
 @GetMapping("/quiz") String quiz(HttpSession s){return s.getAttribute("aluno")==null?"redirect:/aluno":"quiz";}
 @PostMapping("/quiz") String corrigir(@RequestParam Map<String,String> r,HttpSession s){
  Aluno a=(Aluno)s.getAttribute("aluno"); if(a==null)return "redirect:/aluno";
  Map<Integer,String> g=Map.of(1,"b",2,"c",3,"a",4,"c",5,"b",6,"a",7,"c",8,"b",9,"a",10,"c"); int n=0;
  for(int i=1;i<=10;i++)if(g.get(i).equals(r.get("q"+i)))n++;
  s.setAttribute("ultimoResultado",resultados.save(new Resultado(a,n,10))); return "redirect:/resultado";
 }
 @GetMapping("/resultado") String resultado(HttpSession s,Model m){
  Aluno a=(Aluno)s.getAttribute("aluno"); Resultado r=(Resultado)s.getAttribute("ultimoResultado");
  if(a==null)return "redirect:/aluno"; if(r==null)return "redirect:/quiz";
  m.addAttribute("resultado",r);m.addAttribute("historico",resultados.findTop5ByAlunoOrderByDataHoraDesc(a));return "resultado";
 }
}
