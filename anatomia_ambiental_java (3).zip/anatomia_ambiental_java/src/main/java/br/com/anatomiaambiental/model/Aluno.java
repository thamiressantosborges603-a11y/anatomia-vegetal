package br.com.anatomiaambiental.model;
import jakarta.persistence.*;
@Entity @Table(name="alunos")
public class Aluno {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,unique=true) private String email;
 @Column(nullable=false) private String senha;
 @Column(nullable=false) private String nome;
 public Aluno(){}
 public Aluno(String nome,String email,String senha){this.nome=nome;this.email=email;this.senha=senha;}
 public Long getId(){return id;} public String getEmail(){return email;} public String getSenha(){return senha;} public String getNome(){return nome;}
 public void setId(Long id){this.id=id;} public void setEmail(String v){email=v;} public void setSenha(String v){senha=v;} public void setNome(String v){nome=v;}
}
