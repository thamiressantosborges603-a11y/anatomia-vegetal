# Anatomia Vegetal

Projeto escolar em Java com Spring Boot e Thymeleaf.

## Requisitos locais
- Java 17 ou superior
- Maven (ou abrir como projeto Maven no IntelliJ)

## Executar no IntelliJ
Abra o projeto e execute `AnatomiaAmbientalApplication`.
Depois acesse `http://localhost:8080`.

## Login de demonstração
- E-mail: `aluno@escola.com`
- Senha: `123456`

## Publicação
O projeto está preparado para serviços que definem a variável de ambiente `PORT`, como o Railway, usando:

`server.port=${PORT:8080}`

No GitHub, envie o conteúdo desta pasta (não o arquivo ZIP). Depois conecte o repositório ao serviço de hospedagem.
